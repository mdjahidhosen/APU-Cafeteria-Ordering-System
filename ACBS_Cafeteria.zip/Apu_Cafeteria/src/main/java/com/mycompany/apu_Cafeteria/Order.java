package com.mycompany.apu_Cafeteria;

import java.util.ArrayList;

public abstract class Order {
    private String id;
    private String category;
    private String date;

    // Category Description Here
    // 1) Service
    // 2) Facility
    // 3) trainer
    // 4) Others
    
    
    public Order(){}

    public abstract ArrayList<String> getLatestFeedbacks();
    
    public abstract void sendFeedback(String feedbackDataLine);

    
}
