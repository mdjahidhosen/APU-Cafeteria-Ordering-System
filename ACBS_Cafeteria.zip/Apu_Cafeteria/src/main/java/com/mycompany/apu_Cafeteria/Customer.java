package com.mycompany.apu_Cafeteria;

public class Customer extends User {
    
    public Customer(String ID) {
        super(ID);
    }
    
    
}
