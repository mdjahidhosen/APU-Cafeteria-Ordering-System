package com.mycompany.apu_Cafeteria;

public class Manager extends User {

    public Manager(String ID) {
        super(ID);
    }
    
    // Manager's features here
    //
    //
    //
    //Profile
    
}
